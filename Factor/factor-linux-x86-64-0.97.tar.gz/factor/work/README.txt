The 'work' directory is for your own personal vocabularies.
