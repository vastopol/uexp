This is a simple tetris game. To play, open factor (in GUI mode), and run:

"tetris" run

This should open a new window with a running tetris game. The commands are:

left, right arrows: move the current piece left or right
up arrow:           rotate the piece clockwise
down arrow:         lower the piece one row
space bar:          drop the piece
p:                  pause/unpause
n:                  start a new game

TODO:
- rotation of pieces when they're on the far right of the board
- make blocks prettier
- possibly make piece inherit from tetromino
