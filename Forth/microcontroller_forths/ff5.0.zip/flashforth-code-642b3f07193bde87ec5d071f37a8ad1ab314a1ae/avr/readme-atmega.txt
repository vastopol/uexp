FlashForth Atmega readme file
---------------------------

FlashForth is licensed acording to the GNU General Public License

Look in the user guide http://flashforth.sourceforge.net, 
and in the word list wordsAll.txt for further information


REVISION HISTORY
----------------

FlashForth V5.0
----------------
- DO ?DO LEAVE UNLOOP I J LOOP +LOOP
- Old LEAVE used with FOR NEXT has chaned to ENDIT
- CON changed to CONSTANT (Inline code)
- CONSTANT changed to CO: (uses DOCREATE)
- IS and TO made immediate words 
- HI, .FREE
- Assembler in asm.txt
