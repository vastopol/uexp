#include <stddef.h>

unsigned short C4add(unsigned short u)
{
    return u+4;
}
