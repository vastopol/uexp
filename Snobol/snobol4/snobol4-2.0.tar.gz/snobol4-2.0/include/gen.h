/* $Id: gen.h,v 1.1 2003/04/21 22:15:26 phil Exp $ */

/* prototypes for generated functions */

/* from data_init.c */
void init_data __P((void));

/* from syn.c */
void init_syntab __P((void));
