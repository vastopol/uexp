/* $Id: path.h,v 1.5 1996/09/30 21:55:18 phil Exp $ */

#ifndef LD_PATH
#define LD_PATH "/usr/bin/ld"		/* new (SunOS4, bsd4.4) fs org */
#endif /* LD_PATH not defined */

/* SNOLIB_DIR default now in Makefile2.m4 */

/* SNOLIB_A default now in Makefile2.m4 */

#ifndef TMP_DIR
#define TMP_DIR "/tmp"			/* exists on all systems?! */
#endif /* TMP_DIR not defined */
