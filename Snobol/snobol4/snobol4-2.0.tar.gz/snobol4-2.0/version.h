/*
 * generated Thu Jan 1 23:54:49 EST 2015
 * on mail.ultimate.com (FreeBSD)
 * by $Id: configure,v 1.278 2015/01/02 04:54:27 phil Exp $
 */

#define VERSION "2.0"
#define VERSION_DATE "January 1, 2015"
