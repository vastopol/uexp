rm -f *.tmp test.out *~ *.tst *.bin *.dat

