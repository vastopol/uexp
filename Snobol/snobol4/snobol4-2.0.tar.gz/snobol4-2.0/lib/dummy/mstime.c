/* $Id: mstime.c,v 1.6 2003/04/21 22:57:39 phil Exp $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H defined */

#include <stdio.h>

#include "h.h"
#include "snotypes.h"
#include "lib.h"

real_t
mstime() {
    /* use time() to get elapsed time? need to keep base (see borland vers) */
    return 0.0;
}
