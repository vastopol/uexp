/* $Id: suspend.c,v 1.1 2001/12/26 01:57:53 phil Exp $ */

/*
 * process suspend
 * dummy version
 */

/* just leave file empty? */

void
proc_suspend()
{
}
