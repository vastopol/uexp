/* $Id: isnan.c,v 1.1 1996/09/01 04:47:16 phil Exp $ */

int
isnan(x)
    double x;
{
    return 0;
}
