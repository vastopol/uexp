/* xlbuffer.h - definitions for xlbuffer.c */

#ifndef __XLBUFFER_H__
#define __XLBUFFER_H__

#include "xlisp.h"

/* booleans */
#ifndef TRUE
#define TRUE	1
#define FALSE	0
#endif

#endif