//
// TclIconToBitmap.h
//

#ifdef __cplusplus
extern "C" 
#endif
HBITMAP _cdecl TclIconToBitmap(HDC hdc, char *pData, DWORD *pdwWidth, DWORD *pdwHeight);
