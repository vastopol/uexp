#define VERSION "Public domain, 2010-2011 by Christian Stigen Larsen"
